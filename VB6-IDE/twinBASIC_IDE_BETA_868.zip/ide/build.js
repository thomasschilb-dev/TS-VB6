var tbVersionInfo = 'twinBASIC IDE BETA 868'; 

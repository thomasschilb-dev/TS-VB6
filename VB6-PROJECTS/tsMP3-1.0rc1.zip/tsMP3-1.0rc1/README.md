﻿<div align="center">

## Basic VB Media Player 1v


</div>

### Description

This is just an example of begginers. How 4 or 5 lines of coding make up as a MP3 Player with Windows Media ocx. Hope you like it :)

You dont need to write comments.
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2002-11-04 19:26:50
**By**             |[Mr\. CR/\\P](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/mr-cr-p.md)
**Level**          |Beginner
**User Rating**    |3.0 (12 globes from 4 users)
**Compatibility**  |VB 6\.0
**Category**       |[Sound/MP3](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/sound-mp3__1-45.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[Basic\_VB\_M1491951142002\.zip](https://github.com/Planet-Source-Code/mr-cr-p-basic-vb-media-player-1v__1-40411/archive/master.zip)









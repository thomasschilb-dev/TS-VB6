Title: A Systray Icon Example
Description: This is just a small example that will show you how to (1)Minimize your form and make it dissapear. (2)Place your forms icon in the systray (3)have a popup menu that re-opens the form etc,There is probaly a million codes out there for this sort of thing but i thought i might as well share mine with you.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=27491&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

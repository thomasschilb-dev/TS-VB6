Name: Sytray Example
Website: www.activelinx.co.uk
Description: Just a small example i addapted then when your form is minimized it will dissapear to the systray.
There is more advanced versions of this code about but if you like this code and you know what your doing its very easy to upgraded it.